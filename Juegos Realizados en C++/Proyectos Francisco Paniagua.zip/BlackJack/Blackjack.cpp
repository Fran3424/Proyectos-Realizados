#include <time.h>
#include <iostream>
#include "Funciones.h"
#include <stdlib.h>
#include "Estructura.h"
#include <vector>
using namespace std;
int main()
{
	int carta = 0; // se crea una variable para guardar los valores numericos de las cartas
	int puntos1 = 0;// se crea una variable para guardar el puntaje del jugador 1
	int puntos2 = 0;// se crea una variable para guardar el puntaje del jugador 2
	int puntos3 = 0; // se crea una variable para guardar el puntaje del jugador 3
	bool gano = false; // se crea una variable logica para determinar un ganador
	bool termino1 = false; // se crea una variable logica para determinar si el jugador 1 perdio o no quiere continuar pidiendo cartas
	bool termino2 = false;// se crea una variable logica para determinar si el jugador 2 perdio o no quiere continuar pidiendo cartas
	bool termino3 = false; // se crea una variable logica para determinar si el jugador 3 perdio o no quiere continuar pidiendo cartas
	int continuar = 0; // se crea una variable para almacenar la opcion del jugador de si continuar o no
	llenarbaraja(baraja); // se llama a la funcion para llenar la baraja con los valores y simbolos
	//Jugador1***************************************************************************************************************
	cout << "Tu primera carta es:\n"; // se le indica la primer carta al jugador 1
	carta = sacarcarta(baraja, repetido); // se le muestra una carta al jugador
	puntos1 = calcularpuntaje(carta, puntos1, baraja); // se le suma el valor de la carta al puntaje
	cout << "puntaje del jugador 1:\t" << puntos1 << "\n"; // se muestran los puntos del jugador1
	system("pause"); // una pausa
	system("cls"); // se limpia pantalla
	cout << "Tu segunda carta es:\n"; // se le indica la segunda carta al jugador 1
	carta = sacarcarta(baraja, repetido); // se le muestra una carta al jugador
	puntos1 = calcularpuntaje(carta, puntos1, baraja);// se le suma el valor de la carta al puntaje
	cout << "puntaje del jugador 1:\t" << puntos1 << "\n"; // se muestran los puntos del jugador1
	system("pause"); // se hace una pausa
	//Jugador 2*****************************************************************************************************************
	system("cls");
	cout << "Tu primera carta es:\n"; // se le indica la primer carta al jugador 2
	carta = sacarcarta(baraja, repetido);
	puntos2 = calcularpuntaje(carta, puntos2, baraja);
	cout << "puntaje del jugador 2:\t" << puntos2 << "\n";
	system("pause");
	system("cls");
	cout << "Tu segunda carta es:\n"; // se le indica la segunda carta al jugador 2
	carta = sacarcarta(baraja, repetido);
	puntos2 = calcularpuntaje(carta, puntos2, baraja);
	cout << "puntaje del jugador 2:\t" << puntos2 << "\n";
	system("pause");
	//jugador 3******************************************************************************************************************
	system("cls");
	cout << "Tu primera carta es:\n"; // se le indica la primer carta al jugador 3
	carta = sacarcarta(baraja, repetido);
	puntos3 = calcularpuntaje(carta, puntos3, baraja);
	cout << "puntaje del jugador 3:\t" << puntos3 << "\n";
	system("pause");
	system("cls");
	cout << "Tu segunda carta es:\n"; // se le indica la segunda carta al jugador 3
	carta = sacarcarta(baraja, repetido);
	puntos3 = calcularpuntaje(carta, puntos3, baraja);
	cout << "puntaje del jugador 3:\t" << puntos3 << "\n";
	system("pause");

	if (puntos1 == 21) {// si al darle las 2 primeras cartas al jugador queda con 21 puntos ganara automaticamente
		gano = true; // la variable gano pasara a verdadero
		cout << "El ganador es el jugador 1\n"; // se indica que gano el jugador 1
	}
		if (puntos2 == 21) {// si al darle las 2 primeras cartas al jugador queda con 21 puntos ganara automaticamente
			gano = true; // la variable gano pasara a verdadero
			cout << "El ganador es el jugador 2\n"; // se indica que gano el jugador 2
		}

		if (puntos3 == 21) {// si al darle las 2 primeras cartas al jugador queda con 21 puntos ganara automaticamente
			cout << "El ganador es el jugador 3\n"; // se indica que gano el jugador 3
			gano = true; // la variable gano pasara a verdadero
		}

		// el proceso de juego es exactamente el mismo para todos los jugadores 

		//****************************************************Ciclo Jugar************************************************************************************
		while (gano == false) {


			//Jugador1***********************************************************************************************************************************************
			if (termino1 == false) {
				do {
					system("cls"); // se limpia pantalla 
					cout << "\nEl Puntaje del jugador 1 es:\t" << puntos1; // se indican los puntos acumulados del jugador
					cout << "\n¿Desea continuar? presione 1 para continuar o presione 2 para no continuar\n"; // se le solicita al jugador si desea continuar
					cin >> continuar; // se lee la respuesta del jugador
					system("pause"); // se hace una pausa
				} while (continuar < 1 or continuar>2); // si digita numeros fuera de rango de 1 y 2 se repetira hasta que presione numeros validos
			}
			termino1 = continuarjugando(continuar, termino1); // se lleva la desicion del jugador por parametro para determinar si sigue jugando o no

			if (termino1 == true) { // si decidio no seguir jugando solo se mostraran sus puntos cada ronda y ya no se le permitira pedir cartas
				cout << "\nEl puntaje del jugador1:\t" << puntos1 << "\n";
				system("pause");
			}

			if (termino1 == false) { // si decide seguir jugando y sus puntos no han sobrepasado el 21
				cout << "Tu carta es:\n"; // se le indicara una carta
				carta = sacarcarta(baraja, repetido); // se le muestra la carta
				puntos1 = calcularpuntaje(carta, puntos1, baraja); // se le calcula el puntaje con el valor numerico de la carta
				system("cls");
				cout << "\nEl puntaje del jugador1:\t" << puntos1 << "\n"; // se muestra el nuevo puntaje
				system("pause");
			}

			if (puntos1 > 21) { // si los puntos sobrepasan de 21 
				system("cls");
				cout << "Sus puntos se sobrepasaron de 21 jugador 1 haz perdido \n"; // se indicara que el jugador perdio
				system("pause");
				puntos1 = 0; // los puntos pasaran a 0 pues ya habra perdido lo cual lo invalidara
				termino1 = true; // la variable para que no pueda jugar se pondra verdadera
			}
			if (puntos1 == 21) { // si los puntos son 21 exactos 
				gano = true;   // todas las variables logicas de control seran verdaderas lo cual terminara con todo
				termino1 = true;
				termino2 = true;
				termino3 = true;
				system("cls");
				cout << "\nEl ganador es el jugador 1\n"; // ganara  el jugador 1 si sus puntos llegan a ser 21 exacto
				break;
			}

			// este proceso se repite con todos los jugadores y no tiene ninguna diferencia aparte de la diferencia en parametros 

			//jugador 2************************************************************************************************************************************************************************

			if (termino2 == false) {
				do {
					system("cls");
					cout << "\nEl Puntaje del jugador 2 es:\t" << puntos2;
					cout << "\n¿Desea continuar? presione 1 para continuar o presione 2 para no continuar\n";
					cin >> continuar;
					system("pause");
				} while (continuar < 1 or continuar>2);
			}
			termino2 = continuarjugando(continuar, termino2);

			if (termino2 == true) {
				cout << "\nEl puntaje del jugador2:\t" << puntos2 << "\n";
				system("pause");
			}

			if (termino2 == false) {
				cout << "Tu carta es:\n";
				carta = sacarcarta(baraja, repetido);
				puntos2 = calcularpuntaje(carta, puntos2, baraja);
				system("cls");
				cout << "\nEl puntaje del jugador2:\t" << puntos2 << "\n";
				system("pause");

			}

			if (puntos2 > 21) {
				system("cls");
				cout << "Sus puntos se sobrepasaron de 21 jugador 2 haz perdido \n";
				system("pause");
				puntos2 = 0;
				termino2 = true;
			}
			if (puntos2 == 21) {
				gano = true;
				termino1 = true;
				termino2 = true;
				termino3 = true;
				system("cls");
				cout << "\nEl ganador es el jugador 2\n";
				break;
			}



			//jugador3**************************************************************************************************************************************************************************************************************
			if (termino3 == false) {
				do {
					system("cls");
					cout << "\nEl Puntaje del jugador 3 es:\t" << puntos3;
					cout << "\n¿Desea continuar? presione 1 para continuar o presione 2 para no continuar\n";
					cin >> continuar;
					system("pause");
				} while (continuar < 1 or continuar>2);
			}
			termino3 = continuarjugando(continuar, termino3);

			if (termino3 == true) {
				cout << "\nEl puntaje del jugador3:\t" << puntos3 << "\n";
				system("pause");
			}

			if (termino3 == false) {
				cout << "Tu carta es:\n";
				carta = sacarcarta(baraja, repetido);
				puntos3 = calcularpuntaje(carta, puntos3, baraja);
				system("cls");
				cout << "\nEl puntaje del jugador3:\t" << puntos3 << "\n";
				system("pause");

			}

			if (puntos3 > 21) {
				system("cls");
				cout << "Sus puntos se sobrepasaron de 21 jugador 3 haz perdido \n";
				system("pause");
				puntos3 = 0;
				termino3 = true;
			}
			if (puntos3 == 21) {
				gano = true;
				termino1 = true;
				termino2 = true;
				termino3 = true;
				system("cls");
				cout << "\nEl ganador es el jugador 3\n";
				break;
			}



			if (termino1 == true && termino2 == true && termino3 == true) { // si todos decidieron no continuar se calculara un ganador
				declararganador(puntos1, puntos2, puntos3);// se traeran los puntajes y se compararan para determinar un ganador
				break;
			}
		}

	








}

