#pragma once
#include <time.h>
#include <iostream>
#include "Funciones.h"
#include "Estructura.h"
using namespace std;

void llenarbaraja(cartas bar[56]) { //llenar baraja se lleva por parametro el arreglo de estructura de baraja
	char corazon = 3; // se declara una variable para los corazones
	char trebol = 5; // se declara una variable para los treboles
	char diamante = 4; // se declara una variable para los diamantes
	char espada = 6; // se declara una variable para las espadas
	int reiniciador = 1; // reiniciador para sacar numeros de 1 a 13 
	for (int i = 0; i < 14; i++) 
	{
		bar[i].numero = reiniciador++; // se utiliza el reiniciador para que no se sobrepasen los valores numericos
		bar[i].palo = corazon; // en ese rango se ponen corazones
		bar[10].palo = "J \3";
		bar[10].numero = 10;
		bar[11].palo = "k \3";
		bar[11].numero = 10;
		bar[12].palo = "Q \3";
		bar[12].numero = 10;
		bar[13].palo = "AS \3";
		bar[13].numero = 11;

	}

	reiniciador = 1; // se reinicia el reiniciador en 1
	for (int i = 14; i < 28; i++) 
	{
		bar[i].numero = reiniciador++; // se utiliza el reiniciador para que no se sobrepasen los valores numericos
		bar[i].palo = trebol; // en ese rango se ponen treboles
		bar[24].palo = "J \5";
		bar[24].numero = 10;
		bar[25].palo = "k \5";
		bar[25].numero = 10;
		bar[26].palo = "Q \5";
		bar[26].numero = 10;
		bar[27].palo = "AS \5";
		bar[27].numero = 11;

	}
	reiniciador = 1; // se reinicia el reiniciador
	for (int i = 28; i < 42; i++) 

	{
		bar[i].numero = reiniciador++; // se utiliza el reiniciador para que no se sobrepasen los valores numericos
		bar[i].palo = diamante; // en ese rango se ponen diamantes
		bar[38].palo = "J \4"; // se agregan los valores y simbolos de las cartas especiales
		bar[38].numero = 10;
		bar[39].palo = "k \4";
		bar[39].numero = 10;
		bar[40].palo = "Q \4";
		bar[40].numero = 10;
		bar[41].palo = "AS \4";
		bar[41].numero = 11;
	}

	reiniciador = 1; // se reinicia el reiniciador en 1
	for (int i = 42; i < 55; i++) 

	{
		bar[i].numero = reiniciador++; // se utiliza el reiniciador para que no se sobrepasen los valores numericos
		bar[i].palo = espada; // en ese rango se ponen las espadas
		bar[52].palo = "J \6";
		bar[52].numero = 10;
		bar[53].palo = "k \6";
		bar[53].numero = 10;
		bar[54].palo = "Q \6";
		bar[54].numero = 10;
		bar[55].palo = "AS \6";
		bar[55].numero = 11;

	}

}

int  sacarcarta(cartas bar[56], cartas repetido[56]) {
	srand(time(NULL));
	int cart; // crea una variable para almacenar el numero aleatorio de la posicion de la baraja
	do {

		cart =  rand() % 56;// se crea un numero aleatorio de 0 a 56


	} while (repetido[cart].numero == bar[cart].numero && repetido[cart].palo == bar[cart].palo); // se compara con el vector de estructura de repetidos y si es igual repite el ciclo sino se saldra


		repetido[cart].numero = bar[cart].numero; // una vez se salga se asignara la carta ya mostrada al vector de repetidos para que despues al comparar no permita que se repita
		repetido[cart].palo = bar[cart].palo; // una vez se salga se asignara la carta ya mostrada al vector de repetidos para que despues al comparar no permita que se repita




	for (int i = 0; i < 1; i++) {
		{
			cout << "[";
			cout << bar[cart].numero; // se muestra la carta que salio de manera aleatoria
			cout << bar[cart].palo; // se muestra la carta que salio de manera aleatoria
			cout << "]";
			cout << "\n";
			system("pause");
		}

	}

	cart = bar[cart].numero; // se almacena en la variable cart el valor numerico de la carta
	return cart; // se retorna el valor numerico para calcular puntuaciones

}

int calcularpuntaje(int cart, int& punts, cartas bar[56]) { // funcion para calcular puntaje se trae por parametro los puntos totales y el valor numerico de la carta
	punts = cart + punts; // se suman los puntos ya obtenidos con el valor numerico de la carta
	if (cart == 11 && punts > 21) { // si el valor numerico de la carta es 11 quiere decir que es un AS asi que se debe calcular si el puntaje sumado sobrepasa 21
		cart = 1; // si el valor numerico es 11(AS) el valor sumado da mayor a 21 se cambiara el valor numerico a 1
		punts = (punts + cart) - 11; // se suma la carta convertida a 1 y se le resta el 11 ya sumado
	}
	return punts; // se retornan los nuevos puntos

}

bool continuarjugando(int cont, bool& termino) { // funcion para verificar si un jugador quiere continuar jugando
	if (cont == 2) // si la respuesta del jugador llevada por parametro es 2 quiere decir que ya no quiere jugar mas cartas
	{
		termino = true; // por lo tanto termino pasara a ser verdadero
	}

	return termino; // se retorna termino
}

void declararganador(int punts1, int punts2, int punts3) { // funcion para determinar empates o ganador
	system("cls");
	cout << "Puntos del jugador 1:\t" << punts1 << "\n"; // se muestran los puntos del jugador 1
	system("pause");
	system("cls");
	cout << "Puntos del jugador 2:\t" << punts2 << "\n"; // se muestran los puntos del jugador 2
	system("pause");
	system("cls");
	cout << "Puntos del jugador 3:\t" << punts3 << "\n"; // se muestran los puntos del jugador 3
	system("pause");


	if (punts1 > punts2 && punts1 > punts3) { // si el puntaje del jugador 1 es mayor al de los demas
		cout << "\nEl ganador es el jugador 1 pues sus puntos son mayores y no sobrepasan el 21\n";// se indica que gano el jugador 1

	}

	else if (punts2 > punts1 && punts2 > punts3) { // si el puntaje del jugador 2 es mayor al de los demas
		cout << "\nEl ganador es el jugador 2 pues sus puntos son mayores y no sobrepasan el 21\n"; // se indica que gano el jugador 2
	}

	else if (punts3 > punts2 && punts3 > punts1) { // si el puntaje del jugador 3 es mayor al de los demas
		cout << "\nEl ganador es el jugador 3 pues sus puntos son mayores y no sobrepasan el 21\n"; // se indica que el jugador 3 gano
	}


	else if (punts1 == punts2 && punts2 == punts3) { // si todos los puntajes son iguales sera un empate general
		cout << "\nEmpate general\n"; // se indica  empate general
	}

	else if (punts1 == punts2 ) { // si el puntaje del jugador 1 y 2 son iguales y no hay otro puntaje mayor 
		cout << "\nEmpate entre jugador 1 y 2\n"; // se indica que el empate es entre el jugador 1 y 2
	}

	else if (punts1 == punts3) { // si el puntaje del jugador 1 y 3 son iguales y no hay otro puntaje mayor 
		cout << "\nEmpate entre jugador 1 y 3\n"; // se indica que el empate es entre el jugador 1 y 3
	}

	else if (punts2 == punts3) {  // si el puntaje del jugador 2 y 3 son iguales y no hay otro puntaje mayor 
		cout << "\nEmpate entre jugador 2 y 3\n"; // se indica que el empate es entre el jugador 2 y 3
	}


}