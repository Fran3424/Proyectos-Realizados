
#include <iostream> // se agrega la libreria iostream para la entrada y salida de datos
#include <vector> // se agrega la libreria de clase vector en caso de que sea necesario
#include "Funciones.h" // se agrega el archivo de funciones
#include "Estructura.h" // se agrega el archivo de estructura donde vienen las estructuras de datos
using namespace std;
int main()
{
	bool terminoj = false; // variable logica para controlar si ningun jugador puede poner fichas
	bool gano1=false, gano2=false, gano3=false, gano4=false; // variables logicas para controlar si un jugador gano
	int contador = 0;
	string nombre1 = " ", nombre2 = " ",nombre3 = " ", nombre4 = " "; // variables para guardar los nombres de los jugadores
	system("cls"); // se solicitan los nombres de los jugadores y se guardan
	cout << "Escribe tu nombre jugador 1\n";
	cin >> nombre1;
	system("cls");
	cout << "Escribe tu nombre jugador 2\n";
	cin >> nombre2;
	system("cls");
	cout << "Escribe tu nombre jugador 3\n";
	cin >> nombre3;
	system("cls");
	cout << "Escribe tu nombre jugador 4\n";
	cin >> nombre4;
	system("cls");
	generarvalores(); // se generan los valores de las fichas llamando a la funcion de generar los valores 
	asignarfichas(fichas1, fichas2, fichas3, fichas4,nombre1,nombre2,nombre3,nombre4); // se asignan las fichas a los jugadores
	cout << "\n";
	cout  <<nombre1 << "\tPosiciona la primer ficha\n"; // se le indica al primer jugador que posicione una ficha
	system("pause");
	posicionarprimerficha(tabla, fichas1); // se llama a la funcion para posicionar la primer ficha
	cout << "\n";
	mostrartabla(tabla); // se muestra la tabla con la ficha posicionada 


	do { // se crea un ciclo
		if (contador > 0) { // si el contador es mayor a 0 es decir despues de la primera iteracion ya que la primer vez se le solicita al primer jugador poner la primer ficha
		    cout << nombre1 << "\tPosiciona una ficha\n"; // se le solicitara al jugador1 que posicione una ficha 
			system("pause"); // se hace una pausa
			posicionarficha(tabla, fichas1,nombre1); // se llama al proceso para posicionar ficha 
			cout << "\nTablero:\n"; // se indica que se muestra el tablero con las fichas 
			mostrartabla(tabla); // se muestra el tablero con las fichas 
			cout << "\n"; // salto de linea 
			gano1 = verificarsiganojugador(fichas1, gano1); // se verificara despues de la jugada si el jugador gano
		if (gano1 == true) { // si gano1 es verdadero quiere decir que el jugador ya no tiene fichas 
				cout << nombre1 << "\tGano pues se quedo sin fichas"; // se indica que gano el jugador 1
				break; //se rompe el ciclo pues no es necesario continuar
			}
		if (terminoj == false) {
				terminoj = verificarjuego(tabla, fichas1, fichas2, fichas3, fichas4, terminoj);// cada jugada se verifica si se pueden poner fichas
			}
		}
		system("pause");  // una pausa
		cout << "\n"; // salto de linea
		cout << nombre2 << "\tPosiciona una ficha\n"; // se le solicita al jugador 2 que posicione una ficha
		system("pause"); // se hace una pausa
		posicionarficha(tabla, fichas2,nombre2); // se llama al proceso de posicionar ficha
		cout << "\nTablero:\n"; // se indica que se muestra el tablero con las fichas
		mostrartabla(tabla); // se muestra el tablero con las fichas
		cout << "\n"; // salto de linea 
		gano2 = verificarsiganojugador(fichas2, gano2); // se verifica si el jugador que acaba de poner ficha gano
		if (gano2 == true) { //si gano la variable gano pasa verdadero
			cout << nombre2 << "\tGano pues se quedo sin fichas"; // si gano se indica que gano
			break; //se rompe el ciclo pues no es necesario continuar
		}
		if (terminoj == false) {
			terminoj = verificarjuego(tabla, fichas1, fichas2, fichas3, fichas4, terminoj);// cada jugada se verifica si se pueden poner fichas
		}
		system("pause"); // una pausa
		cout << "\n"; // salto de linea
		cout << nombre3 << "\tPosiciona una ficha\n"; // se le indica al jugador 3 que debe posicionar una ficha
		system("pause"); // se hace una pausa
		posicionarficha(tabla, fichas3,nombre3); // se llama a la funcion para que posicione la ficha
		cout << "\nTablero:\n"; // se indica que se muestra el tablero
		mostrartabla(tabla); // se muestra el tablero
		cout << "\n"; // salto de linea
		gano3 = verificarsiganojugador(fichas3, gano3); // se verifica si el jugador gano si no tiene fichas
		if (gano3 == true) { // si el jugador gano
			cout << nombre3 << "\tGano pues se quedo sin fichas"; // se indica que el jugador 3 gano
			break;
		}
		if (terminoj == false) {
			terminoj = verificarjuego(tabla, fichas1, fichas2, fichas3, fichas4, terminoj); // cada jugada se verifica si se pueden poner fichas
		}
		
		system("pause"); // una pausa
		cout << "\n"; // un salto de linea
		cout << nombre4 << "\tPosiciona una ficha\n"; // se le indica al jugador cuatro que debe posicionar una ficha
		system("pause"); // una pausa
		posicionarficha(tabla, fichas4,nombre4); // se llama al proceso de posicionar ficha para que el jugador 4 la posicione
		cout << "\nTablero:\n"; // se indica que se muestra el tablero
		mostrartabla(tabla); // se muestra el tablero
		cout << "\n"; // salto de linea
		gano4 = verificarsiganojugador(fichas4, gano4); // se verifica si el jugador 4 gano validando que no le queden fichas
		if (gano4 == true) { // si no le quedan fichas gano4 sera verdadero
			cout << nombre4 << "\tGano pues se quedo sin fichas"; // se indica que el jugador 4 es el ganador
			break; // se rompe el ciclo pues no es necesario continuar
		}
		if (terminoj == false) {
			terminoj = verificarjuego(tabla, fichas1, fichas2, fichas3, fichas4, terminoj);// cada jugada se verifica si se pueden poner fichas
		}
		system("pause"); // una pausa

		if (terminoj == true) {
			declararganador(fichas1, fichas2, fichas3, fichas4,nombre1,nombre2,nombre3,nombre4);// si ningun jugador puede poner  fichas se calculara un ganador

		}

		contador++; // se incrementa el contador para controlar la primera iteracion ya que el turno del jugador 1 ya habria pasado la primer vez asi que ya la segunda si se le solicta como a todos los demas posicionar una ficha
	} while (terminoj == false); //todo continuara si termino j o sea termino juego sea falso // pero de lo contrario sera verdadero si nadie puede poner fichas


}

