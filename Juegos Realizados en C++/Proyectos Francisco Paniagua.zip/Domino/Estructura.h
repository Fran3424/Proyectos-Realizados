#pragma once
#include <vector>// se agrega la libreria de clase vector para poder crear vectores dinamicos
using namespace std;
struct domino {
	int numeroA; // la estructura tendra un lado a 
	int numeroB; // la estructura tendra un lado b



};
domino fichavalor[28]; // se crea un vector de estructura para los valores de las fichas
domino repetidos1[28]; // se crea un vector de estructura para comparar y evitar fichas repetidas
vector <int>fichas1; // se crea un vector dinamico para las fichas del jugador 1
vector <int>fichas2; // se crea un vector dinamico para las fichas del jugador 2
vector <int>fichas3; // se crea un vector dinamico para las fichas del jugador 3
vector <int>fichas4; // se crea un vector dinamico para las fichas del jugador 4
vector <int>tabla; // se crea un vector dinamico para la tabla donde se posicionan las fichas
