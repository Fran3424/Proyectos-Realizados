#pragma once
#include <iostream> // se agrega la libreria iostream para la entrada y salida de datos
#include <vector> // se agrega la libreria de vector para usar las funcionalidades de la clase vector
#include "Estructura.h" // se agrega el archivo de estructuras para utilizar las estructuras
#include <time.h>
using namespace std;
void generarvalores() {
	int aleatorio = 0;
	int contador = 0;
	int reiniciador = 0; // reiniciador o contador que funciona como iterador para los espacios del vector
	for (int i = 0; i <= 6; i++) // se crean dos ciclos for anidados para sacar los varlores de las fichas el ciclo no puede superar el numero 6 en su iterador
	{
		for (int j = 0; j <= i; j++) // la j no puede sobrepasar el i para poder crear fichas homologas ascendentes de 0 a 6 en una 
		{

			{
				fichavalor[reiniciador].numeroA = i; // el arreglo de tipo estructura en su parte de numero a llevara la i en incremento
				fichavalor[reiniciador].numeroB = j; // el arreglo de tipo estructura en su parte de numbero b llevara la j en incremento

				reiniciador++;//contador o reiniciador que funciona como iterador
			}
		}
	}

}



void asignarfichas(vector<int>& f1, vector<int>& f2, vector<int>& f3, vector<int>& f4,string n1,string n2,string n3,string n4) {
	srand(time(NULL)); // srand null para tiempo para sacar numeros aleatorios
	int aleatorio = 0;
	int contador = 0;
	int reiniciador = 0;
	int extremo1 = 0;
	for (int i = 0; i <= 27; i++) // de 0 a menor o igual 27
	{
		repetidos1[i].numeroA = 9; // se inicializa en 9 para no tener conflicto con las fichas que llevan 0 ya que el vector de estructura siempre comienza en 0 y este vector  se comparara con el vector de valores para que no se repitan las fichas
		repetidos1[i].numeroB = 9; // se inicializa en 9 para no tener conflicto con las fichas que llevan 0 ya que el vector de estructura siempre comienza en 0 y este vector se comparara con el vector de valores  para que no se repitan las fichas
	}
	do { // se crea un ciclo
		aleatorio = rand() % (28); // se genera un numero de 0 a 28
		if (fichavalor[aleatorio].numeroA != repetidos1[aleatorio].numeroA && fichavalor[aleatorio].numeroB != repetidos1[aleatorio].numeroB) { // se generaran numeros aleatorios siempre que salga numeros aleatorios que tengan en la posicion del arreglo valores que ya hayan salido
			f1.push_back(fichavalor[aleatorio].numeroB); // se guardara el numero b de vector de valores en una posicion
			f1.push_back(fichavalor[aleatorio].numeroA); // se guardara el numero a de vector de valores en una posicion
			repetidos1[aleatorio].numeroB = fichavalor[aleatorio].numeroB; // se asignara el valor del vector de valores en la posicion aletoria al vector de repetidos en sus numeros a y sus numeros b
			repetidos1[aleatorio].numeroA = fichavalor[aleatorio].numeroA; // se asignara el valor del vector de valores en la posicion aletoria al vector de repetidos  en sus numeros a y sus numeros b
			contador++; // siempre que esta condicion se repita el contador se incrementara
		}
	} while (contador < 7); // cuando el contador llegue a 6 contando el 0 se terminara el ciclo lo que significara que el vector se lleno con las fichas necesarias
	contador = 0; // se vuelve a poner el contador en 0 para poderlo utilizar nuevamente
	do {// se crea un ciclo
		aleatorio = rand() % (28); // se genera un numero de 0 a 28
		if (fichavalor[aleatorio].numeroA != repetidos1[aleatorio].numeroA && fichavalor[aleatorio].numeroB != repetidos1[aleatorio].numeroB) { // se generaran numeros aleatorios siempre que salga numeros aleatorios que tengan en la posicion del arreglo valores que ya hayan salido
			f2.push_back(fichavalor[aleatorio].numeroB);// se guardara el numero b de vector de valores en una posicion
			f2.push_back(fichavalor[aleatorio].numeroA); // se guardara el numero a de vector de valores en una posicion
			repetidos1[aleatorio].numeroB = fichavalor[aleatorio].numeroB;// se asignara el valor del vector de valores en la posicion aletoria al vector de repetidos  en sus numeros a y sus numeros b
			repetidos1[aleatorio].numeroA = fichavalor[aleatorio].numeroA;// se asignara el valor del vector de valores en la posicion aletoria al vector de repetidos  en sus numeros a y sus numeros b
			contador++;// siempre que esta condicion se repita el contador se incrementara
		}
	} while (contador < 7);// cuando el contador llegue a 6 contando el 0 se terminara el ciclo lo que significara que el vector se lleno con las fichas necesarias

	contador = 0;
	do {
		aleatorio = rand() % (28); // se genera un numero de 0 a 28
		if (fichavalor[aleatorio].numeroA != repetidos1[aleatorio].numeroA && fichavalor[aleatorio].numeroB != repetidos1[aleatorio].numeroB) { // se generaran numeros aleatorios siempre que salga numeros aleatorios que tengan en la posicion del arreglo valores que ya hayan salido
			f3.push_back(fichavalor[aleatorio].numeroB); // se guardara el numero b de vector de valores en una posicion
			f3.push_back(fichavalor[aleatorio].numeroA);// se guardara el numero a de vector de valores en una posicion
			repetidos1[aleatorio].numeroB = fichavalor[aleatorio].numeroB; // se asignara el valor del vector de valores en la posicion aletoria al vector de repetidos  en sus numeros a y sus numeros b
			repetidos1[aleatorio].numeroA = fichavalor[aleatorio].numeroA;// se asignara el valor del vector de valores en la posicion aletoria al vector de repetidos  en sus numeros a y sus numeros b
			contador++;// siempre que esta condicion se repita el contador se incrementara
		}
	} while (contador < 7);// cuando el contador llegue a 6 contando el 0 se terminara el ciclo lo que significara que el vector se lleno con las fichas necesarias

	contador = 0;
	do {
		aleatorio = rand() % (28); // se genera un numero de 0 a 28
		if (fichavalor[aleatorio].numeroA != repetidos1[aleatorio].numeroA && fichavalor[aleatorio].numeroB != repetidos1[aleatorio].numeroB) { // se generaran numeros aleatorios siempre que salga numeros aleatorios que tengan en la posicion del arreglo valores que ya hayan salido
			f4.push_back(fichavalor[aleatorio].numeroB);// se guardara el numero b de vector de valores en una posicion
			f4.push_back(fichavalor[aleatorio].numeroA);// se guardara el numero a de vector de valores en una posicion
			repetidos1[aleatorio].numeroB = fichavalor[aleatorio].numeroB; // se asignara el valor del vector de valores en la posicion aletoria al vector de repetidos  en sus numeros a y sus numeros b
			repetidos1[aleatorio].numeroA = fichavalor[aleatorio].numeroA;// se asignara el valor del vector de valores en la posicion aletoria al vector de repetidos  en sus numeros a y sus numeros b
			contador++; // siempre que esta condicion se repita el contador se incrementara
		}
	} while (contador < 7);  // cuando el contador llegue a 6 contando el 0 se terminara el ciclo lo que significara que el vector se lleno con las fichas necesarias



	cout << "\n";

	system("cls");
	cout << "Fichas del jugador\t" << n1; // se indica que son la fichas del primer jugador
	cout << "\n";
	for (int i = 0; i < f1.size(); i++) // de 0 al tama�o del vector
	{
		cout << "[" << f1[i] << "]"; // se muestra el vector del jugador 1 
	}
	cout << "\n";
	system("pause");
	system("cls");
	cout << "\n";
	cout << "Fichas del jugador\t" << n2;
	cout << "\n";
	for (int i = 0; i < f2.size(); i++) // de 0 al tama�o del vector
	{
		cout << "[" << f2[i] << "]"; // se muestra el vector del jugador 2 
	}
	cout << "\n";
	system("pause");
	system("cls");
	cout << "\n";
	cout << "Fichas del jugador\t" << n3;
	cout << "\n";
	for (int i = 0; i < f3.size(); i++)  // de 0 al tama�o del vector
	{
		cout << "[" << f3[i] << "]"; // se muestra el vector del jugador 3
	}
	cout << "\n";
	system("pause");
	system("cls");
	cout << "\n";
	cout << "Fichas del jugador\t" << n4;
	cout << "\n";
	for (int i = 0; i < f4.size(); i++) // de 0 al tama�o del vector
	{
		cout << "[" << f4[i] << "]"; // se muestra el vector del jugador 4 
	}
	cout << "\n";
	








}

void posicionarprimerficha(vector <int>& tab, vector<int>& f) { // funcion para posicionar la primer ficha
	int op = 0; // variable para almacenar la opcion del jugador
	cout << "\n";
	do {
		system("cls"); // se limpia la pantalla
		cout << "Presione 1 para poner la ficha 1:\t" << "[" << f[0] << "/" << f[1] << "]" << "\n"; // se muestran todas las opciones de fichas posibles para que jugador posicione
		cout << "Presione 2 para poner la ficha 2:\t" << "[" << f[2] << "/" << f[3] << "]" << "\n";
		cout << "Presione 3 para poner la ficha 3:\t" << "[" << f[4] << "/" << f[5] << "]" << "\n";
		cout << "Presione 4 para poner la ficha 4:\t" << "[" << f[6] << "/" << f[7] << "]" << "\n";
		cout << "Presione 5 para poner la ficha 5:\t" << "[" << f[8] << "/" << f[9] << "]" << "\n";
		cout << "Presione 6 para poner la ficha 6:\t" << "[" << f[10] << "/" << f[11] << "]" << "\n";
		cout << "Presione 7 para poner la ficha 7:\t" << "[" << f[12] << "/" << f[13] << "]" << "\n";
		cin >> op; // se recibe la respuesta del jugador


		switch (op) { // se hace un switch con la respuesta


		case 1: // en el caso 1 
			tab.insert(tab.begin(), f[1]); // se pondra la posicion 1 en el vector de tablero donde se ponen las fichas
			tab.insert(tab.begin(), f[0]); // se pondra la posicion 0 en el vector de tablero donde se ponen las fichas
			f[1] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			f[0] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			break;

		case 2:
			tab.insert(tab.begin(), f[3]); // se pondra la posicion 3 en el vector de tablero donde se ponen las fichas
			tab.insert(tab.begin(), f[2]); // se pondra la posicion 2 en el vector de tablero donde se ponen las fichas
			f[3] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			f[2] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			break;

		case 3:
			tab.insert(tab.begin(), f[5]); // se pondra la posicion 5 en el vector de tablero donde se ponen las fichas
			tab.insert(tab.begin(), f[4]); // se pondra la posicion 4 en el vector de tablero donde se ponen las fichas
			f[5] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			f[4] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			break;

		case 4:
			tab.insert(tab.begin(), f[7]); // se pondra la posicion 7 en el vector de tablero donde se ponen las fichas
			tab.insert(tab.begin(), f[6]); // se pondra la posicion 6 en el vector de tablero donde se ponen las fichas
			f[7] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			f[6] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			break;

		case 5:
			tab.insert(tab.begin(), f[9]); // se pondra la posicion 9 en el vector de tablero donde se ponen las fichas
			tab.insert(tab.begin(), f[8]); // se pondra la posicion 8 en el vector de tablero donde se ponen las fichas
			f[9] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			f[8] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			break;

		case 6:
			tab.insert(tab.begin(), f[11]); // se pondra la posicion 11 en el vector de tablero donde se ponen las fichas
			tab.insert(tab.begin(), f[10]); // se pondra la posicion 10 en el vector de tablero donde se ponen las fichas
			f[11] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			f[10] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			break;

		case 7:
			tab.insert(tab.begin(), f[13]); // se pondra la posicion 13 en el vector de tablero donde se ponen las fichas
			tab.insert(tab.begin(), f[12]); // se pondra la posicion 12 en el vector de tablero donde se ponen las fichas
			f[13] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			f[12] = 7; // se cambia el valor de la posicion a 7 para que no se pueda volver a usar
			break;




		}

	} while (op < 1 or op>7); // mientras la opcion sea mayor a 7 o menor a 1 


}

void mostrartabla(vector<int>tab) {

	for (int i = 0; i < tab.size(); i++) // de 0 al tama�o del vector
	{
		cout <<"[" << tab[i] << "]" ; // se muestra la tabla con las fichas posicionadas
	}

	cout << "\n";





}

void posicionarficha(vector <int>& tab, vector<int>& f,string n) { // funcion para posicionar fichas se trae por parametro el vector del jugador segun sea el caso y el tablero para comparar los extremos
	int op = 0;
	int extremoderecho;
	int extremoizquierdo;
	bool terminado = false;
	extremoizquierdo = tab.front(); // se asigna a la variable del extremo izquierdo el valor en de el primer elemento del tablero
	extremoderecho = tab.back();  // se asigna a la variable del extremo derecho el valor en de el ultimo elemento del tablero
	cout << "\n";
	do {
		system("cls");
		cout << "Tablero:\n"; // se indica que es el tablero lo que se muestra
		mostrartabla(tabla); // se llama a la funcion para mostrar el tablero
		cout << "\n";
		cout << "Presione 1 para poner la ficha 1:\t" << "[" << f[0] << "/" << f[1] << "]" << "\n"; // se muestran todas las opciones de fichas posibles para que jugador posicione
		cout << "Presione 2 para poner la ficha 2:\t" << "[" << f[2] << "/" << f[3] << "]" << "\n";
		cout << "Presione 3 para poner la ficha 3:\t" << "[" << f[4] << "/" << f[5] << "]" << "\n";
		cout << "Presione 4 para poner la ficha 4:\t" << "[" << f[6] << "/" << f[7] << "]" << "\n";
		cout << "Presione 5 para poner la ficha 5:\t" << "[" << f[8] << "/" << f[9] << "]" << "\n";
		cout << "Presione 6 para poner la ficha 6:\t" << "[" << f[10] << "/" << f[11] << "]" << "\n";
		cout << "Presione 7 para poner la ficha 7:\t" << "[" << f[12] << "/" << f[13] << "]" << "\n";
		cout << "Para pasar turno presione 8\n"; // una opcion para pasar el turno
		cout << "Turno del jugador\t"<< n << "\n"; // se indica quien esta jugando
		cin >> op;
		switch (op) {


		case 1:
			if (f[0] == extremoderecho) { // si en el vector la posicion cero coincide con el extremo derecho es decir con el final del tablero
				tab.insert(tab.end(), f[0]); // se inserta el valor de la posicion 0 al final del tablero
				tab.insert(tab.end(), f[1]); // se inserta el valor de la posicion 1 al final del tablero
				f[0] = 7; // se cambia el valor de la posicion en el vector a 7 para que no se pueda volver a utilizar y  posteriormente contar los 7 y declarar un ganador
				f[1] = 7;// se cambia el valor de la posicion en el vector a 7 para que no se pueda volver a utilizar y posteriormente contar los 7 y declarar un ganador
				terminado = true; // se cambia la variable booleana a verdadero para terminar el ciclo

			}
			else if (f[0] == extremoizquierdo) { // si en el vector la posicion cero coincide con el extremo derecho es decir con el inicio del tablero
				tab.insert(tab.begin(), f[0]);  // se inserta el valor de la posicion 0 al inicio del tablero
				tab.insert(tab.begin(), f[1]); // se inserta el valor de la posicion 1 al inicio del tablero
				f[0] = 7; // se cambia el valor de la posicion en el vector a 7 para que no se pueda volver a utilizar y posteriormente contar los 7 y declarar un ganador
				f[1] = 7; //se cambia el valor de la posicion en el vector a 7 para que no se pueda volver a utilizar y posteriormente contar los 7 y declarar un ganador
				terminado = true;  // se cambia la variable booleana a verdadero para terminar el ciclo

			}
			else if (f[1] == extremoderecho) { // si en el vector la posicion 1 coincide con el extremo derecho es decir con el final del tablero
				tab.insert(tab.end(), f[1]);  // se inserta el valor de la posicion 1 al final del tablero
				tab.insert(tab.end(), f[0]);  // se inserta el valor de la posicion 0 al final del tablero
				f[0] = 7; // se cambia el valor de la posicion en el vector a 7 para que no se pueda volver a utilizar  y posteriormente contar los 7 y declarar un ganador
				f[1] = 7; //se cambia el valor de la posicion en el vector a 7 para que no se pueda volver a utilizar y posteriormente contar los 7 y declarar un ganador
				terminado = true;  // se cambia la variable booleana a verdadero para terminar el ciclo

			}
			else if (f[1] == extremoizquierdo) { // si en el vector la posicion 1 coincide con el extremo izquierdo es decir con el inicio del tablero
				tab.insert(tab.begin(), f[1]);   // se inserta el valor de la posicion 1 al inicio del tablero
				tab.insert(tab.begin(), f[0]);  // se inserta el valor de la posicion 0 al inicio del tablero
				f[0] = 7; // se cambia el valor de la posicion en el vector a 7 para que no se pueda volver a utilizar y posteriormente contar los 7 y declarar un ganador
				f[1] = 7; //se cambia el valor de la posicion en el vector a 7 para que no se pueda volver a utilizar y posteriormente contar los 7 y declarar un ganador
				terminado = true; // se cambia la variable booleana a verdadero para terminar el ciclo
			}

			else { // en caso de que ningun lado de la ficha coincida con uno de los extremos
				system("cls");
				cout << "\nFicha no valida intente de nuevo\n"; // se indica que la ficha no es valida pues no coincide
				system("pause");
			}
			break; // break del switch
		
			//el mismo proceso se realiza con todas las posiciones que representan las fichas obviamente con diferentes posiciones pero el procedimiento es el mismo se compara los valores de las fichas con los extremos para
			// validar si la ficha se puede poner y posicionarla para que coincidan los numeros de manera adyacente
		case 2:
			if (f[2] == extremoderecho) { 
				tab.insert(tab.end(), f[2]);
				tab.insert(tab.end(), f[3]);
				f[2] = 7;
				f[3] = 7;
				terminado = true;
			

			}
			else if (f[2] == extremoizquierdo) {
				tab.insert(tab.begin(), f[2]); 
				tab.insert(tab.begin(), f[3]);
				f[2] = 7;
				f[3] = 7;
				terminado = true;
			
			}
			else if (f[3] == extremoderecho) {
				tab.insert(tab.end(), f[3]);
				tab.insert(tab.end(), f[2]);
				terminado = true;
				f[2] = 7;
				f[3] = 7;
			}
			else if (f[3] == extremoizquierdo) {
				tab.insert(tab.begin(), f[3]);
				tab.insert(tab.begin(), f[2]);
				terminado = true;
				f[2] = 7;
				f[3] = 7;
			}

			else {
				system("cls");
				cout << "\nFicha no valida intente de nuevo\n";
				system("pause");
			}
			break;

		case 3:
			if (f[4] == extremoderecho) { 
				tab.insert(tab.end(), f[4]);
				tab.insert(tab.end(), f[5]);
				f[4] = 7;
				f[5] = 7;
				terminado = true;
			}
			else if (f[4] == extremoizquierdo) {
				tab.insert(tab.begin(), f[4]); 
				tab.insert(tab.begin(), f[5]);
				f[4] = 7;
				f[5] = 7;
				terminado = true;
			}

			else if (f[5] == extremoderecho) {
				tab.insert(tab.end(), f[5]);
				tab.insert(tab.end(), f[4]);
				f[4] = 7;
				f[5] = 7;
				terminado = true;
			}
			else if (f[5] == extremoizquierdo) {
				tab.insert(tab.begin(), f[5]);
				tab.insert(tab.begin(), f[4]);
				f[4] = 7;
				f[5] = 7;
				terminado = true;

			}

			else {
				system("cls");
				cout << "\nFicha no valida intente de nuevo\n";
				system("pause");;
			}
			break;



		case 4:
			if (f[6] == extremoderecho) { 
				tab.insert(tab.end(), f[6]);
				tab.insert(tab.end(), f[7]);
				f[6] = 7;
				f[7] = 7;
				
				terminado = true;
			}
			else if (f[6] == extremoizquierdo) {
				tab.insert(tab.begin(), f[6]); 
				tab.insert(tab.begin(), f[7]);
				f[6] = 7;
				f[7] = 7;
				terminado = true;
				
			}
			else if (f[7] == extremoderecho) {
				tab.insert(tab.end(), f[7]);
				tab.insert(tab.end(), f[6]);
				f[7] = 7;
				f[6] = 7;
				terminado = true;
			}
			else if (f[7] == extremoizquierdo) {
				tab.insert(tab.begin(), f[7]);
				tab.insert(tab.begin(), f[6]);
				f[7] = 7;
				f[6] = 7;
				terminado = true;

			}
			else {
				system("cls");
				cout << "\nFicha no valida intente de nuevo\n";
				system("pause");
			}
			break;


		case 5:
			if (f[8] == extremoderecho) { 
				tab.insert(tab.end(), f[8]);
				tab.insert(tab.end(), f[9]);
				f[8] = 7;
				f[9] = 7;
				terminado = true;
			
			}
			else if (f[8] == extremoizquierdo) {
				tab.insert(tab.begin(), f[8]); 
				tab.insert(tab.begin(), f[9]);
				f[8] = 7;
				f[9] = 7;
				terminado = true;
			}

			else if (f[9] == extremoderecho) {
				tab.insert(tab.end(), f[9]);
				tab.insert(tab.end(), f[8]);
				f[9] = 7;
				f[8] = 7;
				terminado = true;
			}
			else if (f[9] == extremoizquierdo) {
				tab.insert(tab.begin(), f[9]);
				tab.insert(tab.begin(), f[8]);
				f[9] = 7;
				f[8] = 7;
				terminado = true;

			}

			else {
				system("cls");
				cout << "\nFicha no valida intente de nuevo\n";
				system("pause");
			}
			break;

		case 6:
			if (f[10] == extremoderecho) { 
				tab.insert(tab.end(), f[10]);
				tab.insert(tab.end(), f[11]);
				f[10] = 7;
				f[11] = 7;
				terminado = true;
			
			}
			else if (f[10] == extremoizquierdo) {
				tab.insert(tab.begin(), f[10]); 
				tab.insert(tab.begin(), f[11]);
				f[10] = 7;
				f[11] = 7;
				terminado = true;
			}
			else if (f[11] == extremoderecho) {
				tab.insert(tab.end(), f[11]);
				tab.insert(tab.end(), f[10]);
				f[11] = 7;
				f[10] = 7;
				terminado = true;
			}
			else if (f[11] == extremoizquierdo) {
				tab.insert(tab.begin(), f[11]);
				tab.insert(tab.begin(), f[10]);
				f[11] = 7;
				f[10] = 7;
				terminado = true;

			}

			else {
				system("cls");
				cout << "\nFicha no valida intente de nuevo\n";
				system("pause");
			}


			break;
		


		case 7:
			if (f[12] == extremoderecho) { 
				tab.insert(tab.end(), f[12]);
				tab.insert(tab.end(), f[13]);
				f[12] = 7;
				f[13] = 7;
				terminado = true;

			}
			else if (f[12] == extremoizquierdo) {
				tab.insert(tab.begin(), f[12]); 
				tab.insert(tab.begin(), f[13]);
				f[12] = 7;
				f[13] = 7;
				terminado = true;
	
			}

			else if (f[13] == extremoderecho) {
				tab.insert(tab.end(), f[13]);
				tab.insert(tab.end(), f[12]);
				f[13] = 7;
				f[12] = 7;
				terminado = true;
			}
			else if (f[13] == extremoizquierdo) {
				tab.insert(tab.begin(), f[13]);
				tab.insert(tab.begin(), f[12]);
				f[13] = 7;
				f[12] = 7;
				terminado = true;

			}

			else {
				system("cls");
				cout << "\nFicha no valida intente de nuevo\n";
				system("pause");
			}
			break;

		}

		if (op == 8) { // si se elije la opcion 8 osea la de salir 
			break; // se rompe el ciclo para que juegue el siguiente jugador
		}

	}while (terminado==false); // repetira el ciclo si el usuario se equivoca para que pueda cambiar de jugada o pasar de turno

}

bool verificarjuego(vector <int>& tab, vector<int>& f1, vector<int>& f2, vector<int>& f3, vector<int>& f4, bool &termin) { // esta es para  verificar juego para revisar si ningun jugador puede poner fichas se trae por parametro los vectores de los jugadores y la variable terminoj para terminar el ciclo de juego en caso de que sea necesario
	bool termino1 = false; // se crea una variable logica para determinar si el jugador 1 ya no puede poner fichas
	bool termino2 = false; // se crea una variable logica para determinar si el jugador 2 ya no puede poner fichas
	bool termino3 = false; // se crea una variable logica para determinar si el jugador 3 ya no puede poner fichas
	bool termino4 = false; // se crea una variable logica para determinar si el jugador 4 ya no puede poner fichas
	int contador1 = 0; // se crea un contador 1 que servira para revisar el vector y compararlo con el extremo derecho
	int contador2 = 0; // se crea un contador 2 que servira para revisar el vector y compararlo con el extremo izquierdo
	int extremoizquierdo; // se crea una variable para guardar el valor de extremo izquierdo del vector de tablero
	int extremoderecho; // se crea una variable para guardar el valor de extremo derecho del vector de tablero
	extremoizquierdo = tab.front(); // se asigna el inicio del vector a la variable extremo izquierdo
	extremoderecho = tab.back(); // se asigna el final del vector a la variable extremo derecho


	for (int i = 0; i <= 13; i++) // se crea un ciclo de 0 a 13 
	{
		if (f1[i] != extremoderecho) {  // si recorriendo el vector los numeros no coinciden con el extremo derecho
			contador1++; // el contador1 se incrementara 
		}

		if (f1[i] != extremoizquierdo) { // si recorriendo el vector los numeros no coinciden con el extremo izquierdo
			contador2++; // el contador2 se incrementara 
		}

	}

	if (contador1 == 14 && contador2 == 14) { // si el contador 1 y contador 2 tienen el valor de 14 quiere decir que todos los espacios del vector no coinciden con ningun extremo 
		termino1 = true; // por lo tanto termino1 pasara a verdadero ya que no podria poner mas fichas
	}


	if (contador1 < 14 && contador2 < 14) { // en caso de que el contador1 y contador 2 sean menores a 14 quiere decir que si es posible que el jugador pueda poner una ficha
		termino1 = false; // por lo tanto termino1 sera falso lo que quiere decir que aun puede poner fichas se hace esta comprobacion ya que este procedimiento se llamara al final de cada ronda para comprobar si se pueden poner fichas
	}



	contador1 = 0; // se reinician los contadores
	contador2 = 0;

	// el proceso anterior es el mismo para todos los vectores de los jugadores y se verifica de la misma manera para comprobar que ninguna de las posiciones en el vector es decir las fichas coincidan con los extremos
	// ya que si ninguna coincide quiere decir que el juego debe acabar inevitablemente

	for (int i = 0; i <= 13; i++)
	{
		if (f2[i] != extremoderecho) {
			contador1++;
		}

		if (f2[i] != extremoizquierdo) {
			contador2++;
		}

	}

	if (contador1 == 14 && contador2 == 14) {
		termino2 = true;
	}

	if (contador1 < 14 && contador2 < 14) {
		termino2 = false;
	}


	contador1 = 0;
	contador2 = 0;

	for (int i = 0; i <= 13; i++)
	{
		if (f3[i] != extremoderecho) {
			contador1++;
		}

		if (f3[i] != extremoizquierdo) {
			contador2++;
		}

	}

	if (contador1 == 14 && contador2 == 14) {
		termino3 = true;
	}

	if (contador1 < 14 && contador2 < 14) {
		termino3 = false;
	}

	contador1 = 0;
	contador2 = 0;

	for (int i = 0; i <= 13; i++)
	{
		if (f4[i] != extremoderecho) {
			contador1++;
		}

		if (f4[i] != extremoizquierdo) {
			contador2++;
		}

	}

	if (contador1 == 14 && contador2 == 14) {
		termino4 = true;
	}

	if (contador1 < 14 && contador2 < 14) {
		termino4 = false;
	}




	if (termino1 == true && termino2 == true && termino3 == true && termino4 == true) { // si por medio del procedimiento  se verifican y todos los valores logicos son verdaderos eso indicara que ningun jugador puede posicionar fichas
		system("cls");
		cout << "\nNo se pueden poner mas fichas el juego ha finalizado\n"; // se indica que el juego finalizo debido a que no se pueden posicionar mas fichas
		termin = true; // terminoj sera verdadero si ninguno puede poner fichas
	}

	return termin; // se retorna terminoj que sera verdadero o falso dependiendo de la situacion



}

bool verificarsiganojugador(vector<int>& f ,bool &gan) { //funcion para verificar si despues de cada jugada el vector del jugador esta completamente en 7 lo que significaria que ese jugador gano
	int contador = 0; // se crea un contador
	for (int i = 0; i <= 13; i++) // se crea un ciclo de 0 a 13
	{
		if (f[i] == 7) { // si al recorrer el vector las posiciones valen 7
			contador++; // el contador se incrementara 
	}
	}
	
	if (contador == 14) { // si el contador es 14 quiere decir que todo el vector esta en 7 
		gan = true; // lo cual significa que el jugador gano  y la variable gano cambiara a verdadero
	}

	return gan; // se retorna gano para finalizar el ciclo de juego principal

}

void declararganador(vector<int>& f1, vector<int>& f2, vector<int>& f3, vector<int>& f4, string n1, string n2, string n3, string n4) { // funcion par determinar un ganador si no se pueden poner fichas y ningun jugador se quedo sin fichas
	int suma1 = 0; // se crea un contador para el jugador 1
	int suma2 = 0; // se crea un contador para el jugador 2
	int suma3 = 0; // se crea un contador para el jugador 3
	int suma4 = 0; // se crea un contador para el jugador 4
	for (int i = 0; i <=13; i++)
	{
		if (f1[i] != 7) { //se ignoran los 7 pues son fichas ya utilizadas
			suma1=suma1+f1[i]; //todo lo que no es 7 se suma para crear la suma de puntos
		}
	}


	for (int i = 0; i <= 13; i++)
	{
		if (f2[i] != 7) { //se ignoran los 7 pues son fichas ya utilizadas
			suma2 = suma2 + f2[i]; //todo lo que no es 7 se suma para crear la suma de puntos
		}
	}

	for (int i = 0; i <= 13; i++)
	{
		if (f3[i] != 7) { //se ignoran los 7 pues son fichas ya utilizadas
			suma3 = suma3 + f3[i]; //todo lo que no es 7 se suma para crear la suma de puntos
		}
	}

	for (int i = 0; i <= 13; i++)
	{
		if (f4[i] != 7) { //se ignoran los 7 pues son fichas ya utilizadas
			suma4 = suma4 + f4[i]; //todo lo que no es 7 se suma para crear la suma de puntos
		}
	}

	system("cls");
	cout << "Puntos del jugador:\t"<< n1 <<"\n"; // se indica	que son los puntos del jugador 1
	cout << suma1 << "\n"; // se muestran los puntos del jugador1
	system("pause");
	system("cls");
	cout << "Puntos del jugador:\t" << n2 << "\n"; // se indica	que son los puntos del jugador 2
	cout << suma2 << "\n"; // se muestran los puntos del jugador2
	system("pause");
	system("cls");
	cout << "Puntos del jugador:\t" << n3 << "\n";// se indica	que son los puntos del jugador 3
	cout << suma3 << "\n"; // se muestran los puntos del jugador3
	system("pause");
	system("cls");
	cout << "Puntos del jugador:\t" << n3 << "\n";// se indica	que son los puntos del jugador 4
	cout << suma4 << "\n"; // se muestran los puntos del jugador4
	system("pause");





	

	if (suma1 < suma2 && suma1 < suma3 && suma1 < suma4) { // si la suma del jugador 1 es menor a la de los demas este ganara
		cout << "\nEl jugador cuyas fichas suman menos puntos y por lo tanto gano es:\t" << n1; // se indica que el jugador 1 gano
	}

	if (suma2 < suma1 && suma2 < suma3 && suma2 < suma4) { // si la suma del jugador 2 es menor a la de los demas este ganara
		cout << "\nEl jugador cuyas fichas suman menos puntos y por lo tanto gano es:\t" << n2; // se indica que el jugador 2 gano
	}

	if (suma3 < suma2 && suma3 < suma1 && suma3 < suma4) { // si la suma del jugador 3 es menor a la de los demas este ganara
		cout << "\nEl jugador cuyas fichas suman menos puntos y por lo tanto gano es:\t" << n3; // se indica que el jugador 3 gano
	}

	if (suma4 < suma1 && suma4 < suma2 && suma4 < suma3) { // si la suma del jugador 4 es menor a la de los demas este ganara
		cout << "\nEl jugador cuyas fichas suman menos puntos y por lo tanto gano es:\t" << n4; // se indica que el jugador 4 gano
	}



}